# -*- coding: utf-8 -*-
class CrawlerProcessor(object):
    '''
    classdocs
    '''
    def __init__(self):
        '''
        Constructor
        '''
    @classmethod
    def create(cls):
        return cls()

    def process(self, option):
        pass